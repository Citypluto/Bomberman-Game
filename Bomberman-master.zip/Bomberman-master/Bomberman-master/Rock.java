import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Undestroyable brick class.
 * 
 * @author Anson 
 * @version January 2020
 */
public class Rock extends Actor
{
    
}
